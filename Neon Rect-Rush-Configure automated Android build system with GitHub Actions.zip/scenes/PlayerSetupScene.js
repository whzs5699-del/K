import Phaser from 'phaser';
import { Config } from '../Config.js';

export class PlayerSetupScene extends Phaser.Scene {
    constructor() {
        super('PlayerSetupScene');
        this.player1Name = '';
        this.player2Name = '';
        this.gameMode = 'pvp'; // 'pvp' or 'ai'
        this.aiDifficulty = 'medium';
        this.selectedLevel = 1;
    }

    init(data) {
        this.selectedLevel = data.level || 1;
    }

    preload() {
        this.load.image('bg', 'assets/game-background-vibrant.webp');
    }

    create() {
        const { width, height } = this.scale;

        // Background
        this.add.image(width / 2, height / 2, 'bg')
            .setOrigin(0.5)
            .setAlpha(0.5)
            .setDisplaySize(width, height);

        // Title
        this.add.text(width / 2, height * 0.12, 'إعداد اللعبة', {
            fontSize: '32px',
            fontWeight: 'bold',
            fontFamily: 'Arial',
            color: '#ffffff',
            stroke: '#000000',
            strokeThickness: 6
        }).setOrigin(0.5);

        // Level info
        this.add.text(width / 2, height * 0.18, `المستوى ${this.selectedLevel}`, {
            fontSize: '20px',
            fontFamily: 'Arial',
            color: '#FFD700'
        }).setOrigin(0.5);

        // Game mode selection
        this.add.text(width / 2, height * 0.25, 'نوع اللعبة:', {
            fontSize: '22px',
            fontWeight: 'bold',
            fontFamily: 'Arial',
            color: '#ffffff'
        }).setOrigin(0.5);

        const buttonY = height * 0.31;
        const buttonSpacing = width * 0.45;

        // PvP Button
        this.pvpButton = this.add.text(width / 2 - buttonSpacing / 2, buttonY, 'لاعب ضد لاعب', {
            fontSize: '18px',
            fontFamily: 'Arial',
            color: '#ffffff',
            backgroundColor: '#2196F3',
            padding: { x: 20, y: 12 }
        }).setOrigin(0.5).setInteractive();

        // AI Button
        this.aiButton = this.add.text(width / 2 + buttonSpacing / 2, buttonY, 'لاعب ضد الحاسوب', {
            fontSize: '18px',
            fontFamily: 'Arial',
            color: '#ffffff',
            backgroundColor: '#666666',
            padding: { x: 20, y: 12 }
        }).setOrigin(0.5).setInteractive();

        this.pvpButton.on('pointerdown', () => this.selectGameMode('pvp'));
        this.aiButton.on('pointerdown', () => this.selectGameMode('ai'));

        // AI Difficulty (initially hidden)
        this.difficultyContainer = this.add.container(0, 0);
        this.difficultyContainer.setAlpha(0);

        const diffY = height * 0.38;
        const diffLabel = this.add.text(width / 2, diffY, 'مستوى الصعوبة:', {
            fontSize: '18px',
            fontFamily: 'Arial',
            color: '#ffffff'
        }).setOrigin(0.5);

        const diffButtonY = diffY + 35;
        const diffSpacing = width * 0.28;

        this.easyButton = this.add.text(width / 2 - diffSpacing, diffButtonY, 'سهل', {
            fontSize: '16px',
            fontFamily: 'Arial',
            color: '#ffffff',
            backgroundColor: '#4CAF50',
            padding: { x: 18, y: 10 }
        }).setOrigin(0.5).setInteractive();

        this.mediumButton = this.add.text(width / 2, diffButtonY, 'متوسط', {
            fontSize: '16px',
            fontFamily: 'Arial',
            color: '#ffffff',
            backgroundColor: '#FF9800',
            padding: { x: 18, y: 10 }
        }).setOrigin(0.5).setInteractive();

        this.hardButton = this.add.text(width / 2 + diffSpacing, diffButtonY, 'صعب', {
            fontSize: '16px',
            fontFamily: 'Arial',
            color: '#ffffff',
            backgroundColor: '#F44336',
            padding: { x: 18, y: 10 }
        }).setOrigin(0.5).setInteractive();

        this.easyButton.on('pointerdown', () => this.selectDifficulty('easy'));
        this.mediumButton.on('pointerdown', () => this.selectDifficulty('medium'));
        this.hardButton.on('pointerdown', () => this.selectDifficulty('hard'));

        this.difficultyContainer.add([diffLabel, this.easyButton, this.mediumButton, this.hardButton]);
        this.selectDifficulty('medium'); // Default

        // Player names input
        const nameY = height * 0.48;
        this.add.text(width / 2, nameY, 'أسماء اللاعبين:', {
            fontSize: '22px',
            fontWeight: 'bold',
            fontFamily: 'Arial',
            color: '#ffffff'
        }).setOrigin(0.5);

        // Player 1 name
        const p1Y = nameY + 45;
        this.add.text(width * 0.15, p1Y, 'اللاعب 1:', {
            fontSize: '18px',
            fontFamily: 'Arial',
            color: Config.players[0].colorHex
        }).setOrigin(0, 0.5);

        this.player1Input = this.add.text(width * 0.35, p1Y, 'اللاعب 1', {
            fontSize: '18px',
            fontFamily: 'Arial',
            color: '#ffffff',
            backgroundColor: '#333333',
            padding: { x: 15, y: 10 },
            fixedWidth: width * 0.5
        }).setOrigin(0, 0.5).setInteractive();

        // Player 2 name
        const p2Y = p1Y + 50;
        this.player2Label = this.add.text(width * 0.15, p2Y, 'اللاعب 2:', {
            fontSize: '18px',
            fontFamily: 'Arial',
            color: Config.players[1].colorHex
        }).setOrigin(0, 0.5);

        this.player2Input = this.add.text(width * 0.35, p2Y, 'اللاعب 2', {
            fontSize: '18px',
            fontFamily: 'Arial',
            color: '#ffffff',
            backgroundColor: '#333333',
            padding: { x: 15, y: 10 },
            fixedWidth: width * 0.5
        }).setOrigin(0, 0.5).setInteractive();

        // Mobile keyboard input
        this.player1Input.on('pointerdown', () => this.editPlayerName(1));
        this.player2Input.on('pointerdown', () => this.editPlayerName(2));

        // Start button
        this.startButton = this.add.text(width / 2, height * 0.75, 'ابدأ اللعبة', {
            fontSize: '28px',
            fontWeight: 'bold',
            fontFamily: 'Arial',
            color: '#ffffff',
            backgroundColor: '#4CAF50',
            padding: { x: 40, y: 15 }
        }).setOrigin(0.5).setInteractive();

        this.startButton.on('pointerdown', () => this.startGame());
        this.startButton.on('pointerover', () => this.startButton.setScale(1.05));
        this.startButton.on('pointerout', () => this.startButton.setScale(1));

        // Back button
        this.backButton = this.add.text(width / 2, height * 0.85, '← رجوع للقائمة', {
            fontSize: '18px',
            fontFamily: 'Arial',
            color: '#ffffff',
            backgroundColor: '#666666',
            padding: { x: 20, y: 10 }
        }).setOrigin(0.5).setInteractive();

        this.backButton.on('pointerdown', () => this.scene.start('MenuScene'));
        this.backButton.on('pointerover', () => this.backButton.setScale(1.05));
        this.backButton.on('pointerout', () => this.backButton.setScale(1));

        // Initialize default mode
        this.selectGameMode('pvp');

        this.scale.on('resize', this.handleResize, this);
    }

    selectGameMode(mode) {
        this.gameMode = mode;

        if (mode === 'pvp') {
            this.pvpButton.setStyle({ backgroundColor: '#2196F3' });
            this.aiButton.setStyle({ backgroundColor: '#666666' });
            this.difficultyContainer.setAlpha(0);
            this.player2Label.setText('اللاعب 2:');
            this.player2Input.setText(this.player2Name || 'اللاعب 2');
        } else {
            this.pvpButton.setStyle({ backgroundColor: '#666666' });
            this.aiButton.setStyle({ backgroundColor: '#2196F3' });
            this.difficultyContainer.setAlpha(1);
            this.player2Label.setText('الحاسوب:');
            
            const diffNames = { easy: 'سهل', medium: 'متوسط', hard: 'صعب' };
            this.player2Input.setText('حاسوب (' + diffNames[this.aiDifficulty] + ')');
        }
    }

    selectDifficulty(difficulty) {
        this.aiDifficulty = difficulty;

        // Reset all button styles
        this.easyButton.setStyle({ backgroundColor: '#4CAF50', alpha: 0.6 });
        this.mediumButton.setStyle({ backgroundColor: '#FF9800', alpha: 0.6 });
        this.hardButton.setStyle({ backgroundColor: '#F44336', alpha: 0.6 });

        // Highlight selected
        if (difficulty === 'easy') this.easyButton.setAlpha(1);
        else if (difficulty === 'medium') this.mediumButton.setAlpha(1);
        else this.hardButton.setAlpha(1);

        // Update AI name
        if (this.gameMode === 'ai') {
            const diffNames = { easy: 'سهل', medium: 'متوسط', hard: 'صعب' };
            this.player2Input.setText('حاسوب (' + diffNames[difficulty] + ')');
        }
    }

    editPlayerName(playerNum) {
        const currentName = playerNum === 1 ? this.player1Name || 'اللاعب 1' : this.player2Name || 'اللاعب 2';
        
        // Use browser prompt for mobile-friendly input
        const newName = prompt(`أدخل اسم اللاعب ${playerNum}:`, currentName);
        
        if (newName && newName.trim()) {
            if (playerNum === 1) {
                this.player1Name = newName.trim();
                this.player1Input.setText(this.player1Name);
            } else {
                this.player2Name = newName.trim();
                this.player2Input.setText(this.player2Name);
            }
        }
    }

    startGame() {
        const p1Name = this.player1Name || 'اللاعب 1';
        const p2Name = this.gameMode === 'ai' ? 'الحاسوب' : (this.player2Name || 'اللاعب 2');

        this.scene.start('GameScene', {
            level: this.selectedLevel,
            totalWins: [0, 0],
            gameMode: this.gameMode,
            aiDifficulty: this.aiDifficulty,
            player1Name: p1Name,
            player2Name: p2Name
        });
    }

    handleResize(gameSize) {
        // Static layout for simplicity
    }
}
