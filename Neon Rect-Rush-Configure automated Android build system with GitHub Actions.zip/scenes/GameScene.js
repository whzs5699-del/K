import Phaser from 'phaser';
import { Config } from '../Config.js';

export class GameScene extends Phaser.Scene {
    constructor() {
        super('GameScene');
        this.currentPlayer = 0;
        this.scores = [0, 0];
        this.totalWins = [0, 0]; // Track wins across levels
        this.hLines = []; // state: 0 (empty), 1 (P1), 2 (P2)
        this.vLines = [];
        this.boxes = []; // state: 0 (empty), 1 (P1), 2 (P2), -1 (obstacle)
        this.dots = [];
        this.lineObjects = { h: [], v: [] };
        this.boxObjects = [];
        this.obstacleBoxes = []; // Track which boxes are obstacles
        this.dragStartDot = null;
        this.dragLine = null;
        this.turnTimer = Config.turnTime;
        this.timerText = null;
        this.timerEvent = null;
        this.undoAvailable = [true, true]; // one undo per player
        this.lastMove = null;
        this.currentLevel = 1;
        this.powerUpsRemaining = [
            { suggestMove: 1, skipTurn: 1, addTime: 1 },
            { suggestMove: 1, skipTurn: 1, addTime: 1 }
        ];
        this.suggestedLine = null;
    }

    init(data) {
        // Initialize level from data or default to 1
        this.currentLevel = data.level || 1;
        this.totalWins = data.totalWins || [0, 0];
        this.gameMode = data.gameMode || 'pvp';
        this.aiDifficulty = data.aiDifficulty || 'medium';
        this.player1Name = data.player1Name || 'اللاعب 1';
        this.player2Name = data.player2Name || 'اللاعب 2';
        this.isAIThinking = false;
        
        // Apply level-specific colors
        const levelColors = Config.levelColors[this.currentLevel - 1];
        this.levelPlayerColors = [
            {
                ...Config.players[0],
                name: this.player1Name,
                color: levelColors.p1.color,
                boxColor: levelColors.p1.color,
                colorHex: levelColors.p1.hex
            },
            {
                ...Config.players[1],
                name: this.player2Name,
                color: levelColors.p2.color,
                boxColor: levelColors.p2.color,
                colorHex: levelColors.p2.hex
            }
        ];
    }

    preload() {
        this.load.image('bg', 'assets/game-background-vibrant.webp');
    }

    create() {
        const bg = this.add.image(this.scale.width / 2, this.scale.height / 2, 'bg')
            .setOrigin(0.5)
            .setAlpha(0.5)
            .setDisplaySize(this.scale.width, this.scale.height)
            .setName('bg');

        // Randomize starting player
        this.currentPlayer = Math.random() < 0.5 ? 0 : 1;

        this.initGrid();
        this.createUI();
        this.setupDragInput();
        this.startTurnTimer();

        this.scale.on('resize', this.handleResize, this);
        this.handleResize(this.scale);
        
        // Show power-ups tutorial on first level
        if (this.currentLevel === 1) {
            this.time.delayedCall(1000, () => this.showPowerUpsTutorial());
        }
    }

    showPowerUpsTutorial() {
        const { width, height } = this.scale;

        // Semi-transparent overlay
        const overlay = this.add.rectangle(width / 2, height / 2, width, height, 0x000000, 0.85)
            .setOrigin(0.5)
            .setDepth(200)
            .setInteractive();

        // Tutorial container
        const tutorialContainer = this.add.container(width / 2, height / 2).setDepth(201);

        // Title
        const title = this.add.text(0, -height * 0.25, 'المساعدات المتاحة', {
            fontSize: '32px',
            fontWeight: 'bold',
            fontFamily: Config.fontFamily,
            color: '#FFD700',
            stroke: '#000000',
            strokeThickness: 6
        }).setOrigin(0.5);

        // Power-ups explanation
        const powerUps = [
            { icon: '💡', name: 'اقتراح خط', desc: 'يظهر لك أفضل خط للعب' },
            { icon: '⏭', name: 'تخطي الدور', desc: 'يلعب لك دورين متتاليين' },
            { icon: '⏱', name: '+5 ثواني', desc: 'يضيف 5 ثواني للوقت' }
        ];

        const startY = -height * 0.08;
        const spacing = height * 0.12;

        powerUps.forEach((powerUp, i) => {
            const y = startY + (i * spacing);
            
            // Icon
            const icon = this.add.text(-width * 0.25, y, powerUp.icon, {
                fontSize: '36px'
            }).setOrigin(0.5);

            // Name
            const name = this.add.text(-width * 0.15, y - 8, powerUp.name, {
                fontSize: '22px',
                fontWeight: 'bold',
                fontFamily: Config.fontFamily,
                color: '#ffffff'
            }).setOrigin(0, 0.5);

            // Description
            const desc = this.add.text(-width * 0.15, y + 12, powerUp.desc, {
                fontSize: '16px',
                fontFamily: Config.fontFamily,
                color: '#cccccc'
            }).setOrigin(0, 0.5);

            tutorialContainer.add([icon, name, desc]);
        });

        tutorialContainer.add(title);

        // Notice
        const notice = this.add.text(0, height * 0.2, 'كل لاعب لديه استخدام واحد لكل مساعدة في كل مرحلة', {
            fontSize: '16px',
            fontFamily: Config.fontFamily,
            color: '#FFC107',
            align: 'center',
            wordWrap: { width: width * 0.7 }
        }).setOrigin(0.5);

        tutorialContainer.add(notice);

        // Close button
        const closeBtn = this.add.text(0, height * 0.3, 'فهمت!', {
            fontSize: '24px',
            fontWeight: 'bold',
            fontFamily: Config.fontFamily,
            color: '#ffffff',
            backgroundColor: '#4CAF50',
            padding: { x: 40, y: 12 }
        }).setOrigin(0.5).setInteractive();

        closeBtn.on('pointerdown', () => {
            overlay.destroy();
            tutorialContainer.destroy();
        });

        closeBtn.on('pointerover', () => closeBtn.setScale(1.1));
        closeBtn.on('pointerout', () => closeBtn.setScale(1));

        tutorialContainer.add(closeBtn);

        // Fade in animation
        overlay.setAlpha(0);
        tutorialContainer.setAlpha(0);

        this.tweens.add({
            targets: [overlay, tutorialContainer],
            alpha: 1,
            duration: 300
        });
    }

    initGrid() {
        const levelData = Config.levels[this.currentLevel - 1];
        const { rows, cols } = { rows: levelData.rows, cols: levelData.cols };

        // Initialize state arrays
        this.hLines = Array.from({ length: rows }, () => Array(cols - 1).fill(0));
        this.vLines = Array.from({ length: rows - 1 }, () => Array(cols).fill(0));
        this.boxes = Array.from({ length: rows - 1 }, () => Array(cols - 1).fill(0));
        this.obstacleBoxes = [];

        this.gridContainer = this.add.container(0, 0);

        // Apply obstacles for this level
        this.applyObstacles(levelData.obstacles, rows, cols);

        // Boxes (background rectangles for points)
        for (let r = 0; r < rows - 1; r++) {
            this.boxObjects[r] = [];
            for (let c = 0; c < cols - 1; c++) {
                const isObstacle = this.boxes[r][c] === -1;
                const rect = this.add.rectangle(0, 0, Config.grid.spacing, Config.grid.spacing, 
                    isObstacle ? Config.obstacleColor : 0xffffff, 
                    isObstacle ? 0.4 : 0);
                
                if (isObstacle) {
                    // Add X pattern for obstacles
                    const x1 = this.add.line(0, 0, 
                        -Config.grid.spacing * 0.3, -Config.grid.spacing * 0.3,
                        Config.grid.spacing * 0.3, Config.grid.spacing * 0.3,
                        0x666666, 0.6);
                    x1.setLineWidth(3);
                    
                    const x2 = this.add.line(0, 0,
                        Config.grid.spacing * 0.3, -Config.grid.spacing * 0.3,
                        -Config.grid.spacing * 0.3, Config.grid.spacing * 0.3,
                        0x666666, 0.6);
                    x2.setLineWidth(3);
                    
                    this.gridContainer.add([x1, x2]);
                    rect.setData('obstacleMarks', [x1, x2]);
                }
                
                this.gridContainer.add(rect);
                this.boxObjects[r][c] = rect;
            }
        }

        // Horizontal visual lines (subtle guides)
        for (let r = 0; r < rows; r++) {
            this.lineObjects.h[r] = [];
            for (let c = 0; c < cols - 1; c++) {
                const line = this.add.rectangle(0, 0, Config.grid.spacing, Config.lineThickness, 0xcccccc, 0.15);
                line.setOrigin(0, 0.5);
                line.setData({ type: 'h', r, c });
                this.gridContainer.add(line);
                this.lineObjects.h[r][c] = line;
            }
        }

        // Vertical visual lines (subtle guides)
        for (let r = 0; r < rows - 1; r++) {
            this.lineObjects.v[r] = [];
            for (let c = 0; c < cols; c++) {
                const line = this.add.rectangle(0, 0, Config.lineThickness, Config.grid.spacing, 0xcccccc, 0.15);
                line.setOrigin(0.5, 0);
                line.setData({ type: 'v', r, c });
                this.gridContainer.add(line);
                this.lineObjects.v[r][c] = line;
            }
        }

        // Dots (interactive)
        for (let r = 0; r < rows; r++) {
            this.dots[r] = [];
            for (let c = 0; c < cols; c++) {
                const dot = this.add.circle(0, 0, Config.dotRadius, 0xffffff, 0.8);
                dot.setInteractive();
                dot.setData({ r, c });
                this.gridContainer.add(dot);
                this.dots[r][c] = dot;
            }
        }
    }

    applyObstacles(obstacles, rows, cols) {
        if (!obstacles || obstacles.length === 0) return;

        obstacles.forEach(obstacle => {
            const { type, baseR, baseC, rotation = 0 } = obstacle;
            
            if (type === 'L') {
                this.applyLShapeObstacle(baseR, baseC, rotation, rows, cols);
            } else if (type === 'cross') {
                this.applyCrossObstacle(baseR, baseC, rows, cols);
            }
        });
    }

    applyLShapeObstacle(baseR, baseC, rotation, rows, cols) {
        // L-shape consists of 3 boxes forming an L
        // Base rotation 0: boxes at (baseR, baseC), (baseR+1, baseC), (baseR+1, baseC+1)
        let positions = [];
        
        switch(rotation) {
            case 0: // Normal L
                positions = [
                    [baseR, baseC],
                    [baseR + 1, baseC],
                    [baseR + 1, baseC + 1]
                ];
                break;
            case 90: // Rotated 90° clockwise
                positions = [
                    [baseR, baseC],
                    [baseR, baseC + 1],
                    [baseR + 1, baseC]
                ];
                break;
            case 180: // Rotated 180°
                positions = [
                    [baseR, baseC],
                    [baseR, baseC + 1],
                    [baseR + 1, baseC + 1]
                ];
                break;
            case 270: // Rotated 270° clockwise
                positions = [
                    [baseR, baseC + 1],
                    [baseR + 1, baseC],
                    [baseR + 1, baseC + 1]
                ];
                break;
        }

        positions.forEach(([r, c]) => {
            if (r >= 0 && r < rows - 1 && c >= 0 && c < cols - 1) {
                this.boxes[r][c] = -1; // Mark as obstacle
                this.obstacleBoxes.push({ r, c });
            }
        });
    }

    applyCrossObstacle(baseR, baseC, rows, cols) {
        // Cross shape: center box plus 4 adjacent boxes
        const positions = [
            [baseR, baseC], // center
            [baseR - 1, baseC], // top
            [baseR + 1, baseC], // bottom
            [baseR, baseC - 1], // left
            [baseR, baseC + 1]  // right
        ];

        positions.forEach(([r, c]) => {
            if (r >= 0 && r < rows - 1 && c >= 0 && c < cols - 1) {
                this.boxes[r][c] = -1; // Mark as obstacle
                this.obstacleBoxes.push({ r, c });
            }
        });
    }

    createUI() {
        const { width, height } = this.scale;
        const margin = width * 0.05;

        this.playerLabels = [];
        this.playerScores = [];
        this.undoButtons = [];
        this.powerUpButtons = [[], []]; // Array for each player's power-up buttons

        this.levelPlayerColors.forEach((player, i) => {
            const x = i === 0 ? margin + 80 : width - margin - 80;
            const y = height * 0.08;

            const nameText = this.add.text(x, y, player.name, {
                fontSize: '20px',
                fontFamily: Config.fontFamily,
                color: '#ffffff',
                align: 'center'
            }).setOrigin(0.5);

            const scoreText = this.add.text(x, y + 35, '0', {
                fontSize: '42px',
                fontWeight: 'bold',
                fontFamily: Config.fontFamily,
                color: player.colorHex,
                align: 'center'
            }).setOrigin(0.5);

            // Undo button
            const undoBtn = this.add.text(x, y + 75, '↶ تراجع', {
                fontSize: '16px',
                fontFamily: Config.fontFamily,
                color: '#ffffff',
                backgroundColor: '#333333',
                padding: { x: 10, y: 5 }
            }).setOrigin(0.5).setInteractive().setAlpha(0.5);

            undoBtn.on('pointerdown', () => this.handleUndo(i));

            this.playerLabels.push(nameText);
            this.playerScores.push(scoreText);
            this.undoButtons.push(undoBtn);

            // Power-up buttons
            const powerUpY = y + 105;
            const powerUpSpacing = 38;
            let powerUpIndex = 0;

            // Suggest Move button
            const suggestBtn = this.add.text(x - powerUpSpacing, powerUpY, '💡', {
                fontSize: '24px',
                backgroundColor: '#4CAF50',
                padding: { x: 6, y: 4 }
            }).setOrigin(0.5).setInteractive();

            const suggestCount = this.add.text(x - powerUpSpacing + 12, powerUpY - 12, '1', {
                fontSize: '12px',
                fontWeight: 'bold',
                fontFamily: Config.fontFamily,
                color: '#ffffff',
                backgroundColor: '#F44336',
                padding: { x: 4, y: 2 }
            }).setOrigin(0.5);

            suggestBtn.on('pointerdown', () => this.usePowerUp(i, 'suggestMove'));
            
            // Skip Turn button
            const skipBtn = this.add.text(x, powerUpY, '⏭', {
                fontSize: '24px',
                backgroundColor: '#FF9800',
                padding: { x: 6, y: 4 }
            }).setOrigin(0.5).setInteractive();

            const skipCount = this.add.text(x + 12, powerUpY - 12, '1', {
                fontSize: '12px',
                fontWeight: 'bold',
                fontFamily: Config.fontFamily,
                color: '#ffffff',
                backgroundColor: '#F44336',
                padding: { x: 4, y: 2 }
            }).setOrigin(0.5);

            skipBtn.on('pointerdown', () => this.usePowerUp(i, 'skipTurn'));

            // Add Time button
            const timeBtn = this.add.text(x + powerUpSpacing, powerUpY, '⏱', {
                fontSize: '24px',
                backgroundColor: '#2196F3',
                padding: { x: 6, y: 4 }
            }).setOrigin(0.5).setInteractive();

            const timeCount = this.add.text(x + powerUpSpacing + 12, powerUpY - 12, '1', {
                fontSize: '12px',
                fontWeight: 'bold',
                fontFamily: Config.fontFamily,
                color: '#ffffff',
                backgroundColor: '#F44336',
                padding: { x: 4, y: 2 }
            }).setOrigin(0.5);

            timeBtn.on('pointerdown', () => this.usePowerUp(i, 'addTime'));

            this.powerUpButtons[i] = [
                { button: suggestBtn, count: suggestCount, type: 'suggestMove' },
                { button: skipBtn, count: skipCount, type: 'skipTurn' },
                { button: timeBtn, count: timeCount, type: 'addTime' }
            ];

            // Add hover effects
            [suggestBtn, skipBtn, timeBtn].forEach(btn => {
                btn.on('pointerover', () => btn.setScale(1.1));
                btn.on('pointerout', () => btn.setScale(1));
            });
        });

        // Timer display
        this.timerText = this.add.text(width / 2, height * 0.06, '15', {
            fontSize: '32px',
            fontWeight: 'bold',
            fontFamily: Config.fontFamily,
            color: '#ffffff',
            stroke: '#000000',
            strokeThickness: 4
        }).setOrigin(0.5);

        // Status text
        this.statusText = this.add.text(width / 2, height * 0.92, '', {
            fontSize: '20px',
            fontFamily: Config.fontFamily,
            color: '#ffffff',
            backgroundColor: this.levelPlayerColors[0].colorHex + 'AA',
            padding: { x: 15, y: 8 }
        }).setOrigin(0.5);

        // Level indicator
        this.levelText = this.add.text(width / 2, height * 0.14, `المستوى ${this.currentLevel}`, {
            fontSize: '18px',
            fontFamily: Config.fontFamily,
            color: '#ffffff',
            backgroundColor: '#00000066',
            padding: { x: 12, y: 6 }
        }).setOrigin(0.5);

        // Menu button (top left)
        this.menuButton = this.add.text(margin, height * 0.92, '☰ القائمة', {
            fontSize: '18px',
            fontFamily: Config.fontFamily,
            color: '#ffffff',
            backgroundColor: '#00000088',
            padding: { x: 12, y: 8 }
        }).setOrigin(0, 0.5).setInteractive();

        this.menuButton.on('pointerdown', () => {
            if (this.timerEvent) this.timerEvent.remove();
            this.scene.start('MenuScene');
        });

        this.menuButton.on('pointerover', () => this.menuButton.setScale(1.1));
        this.menuButton.on('pointerout', () => this.menuButton.setScale(1));

        this.updateTurnIndicator();
    }

    setupDragInput() {
        // Drag from dot to dot to create lines
        this.input.on('gameobjectdown', (pointer, gameObject) => {
            // Disable input during AI turn
            if (this.gameMode === 'ai' && this.currentPlayer === 1) return;
            
            const data = gameObject.data.getAll();
            if (data.r !== undefined && data.c !== undefined) {
                this.dragStartDot = { r: data.r, c: data.c };
                
                // Create preview line
                this.dragLine = this.add.line(
                    0, 0, 
                    this.getDotWorldX(data.c), 
                    this.getDotWorldY(data.r),
                    this.getDotWorldX(data.c), 
                    this.getDotWorldY(data.r),
                    this.levelPlayerColors[this.currentPlayer].color,
                    0.5
                );
                this.dragLine.setLineWidth(Config.lineThickness);
            }
        });

        this.input.on('pointermove', (pointer) => {
            if (this.dragStartDot && this.dragLine) {
                this.dragLine.setTo(
                    this.getDotWorldX(this.dragStartDot.c),
                    this.getDotWorldY(this.dragStartDot.r),
                    pointer.x,
                    pointer.y
                );
            }
        });

        this.input.on('gameobjectup', (pointer, gameObject) => {
            if (!this.dragStartDot) return;

            const data = gameObject.data.getAll();
            if (data.r !== undefined && data.c !== undefined) {
                const endDot = { r: data.r, c: data.c };
                this.tryCreateLine(this.dragStartDot, endDot);
            }

            // Clean up
            if (this.dragLine) {
                this.dragLine.destroy();
                this.dragLine = null;
            }
            this.dragStartDot = null;
        });

        this.input.on('pointerup', () => {
            // Clean up if released outside a dot
            if (this.dragLine) {
                this.dragLine.destroy();
                this.dragLine = null;
            }
            this.dragStartDot = null;
        });
    }

    getDotWorldX(c) {
        return this.gridContainer.x + c * Config.grid.spacing;
    }

    getDotWorldY(r) {
        return this.gridContainer.y + r * Config.grid.spacing;
    }

    tryCreateLine(start, end) {
        const dr = end.r - start.r;
        const dc = end.c - start.c;

        // Check if adjacent (only horizontal or vertical, one unit)
        if (Math.abs(dr) + Math.abs(dc) !== 1) return;

        let type, r, c;
        if (dr === 0) {
            // Horizontal line
            type = 'h';
            r = start.r;
            c = Math.min(start.c, end.c);
            
            if (this.hLines[r][c] !== 0) return; // Already drawn
            
            this.onLineDrawn(type, r, c);
        } else {
            // Vertical line
            type = 'v';
            r = Math.min(start.r, end.r);
            c = start.c;
            
            if (this.vLines[r][c] !== 0) return; // Already drawn
            
            this.onLineDrawn(type, r, c);
        }
    }

    onLineDrawn(type, r, c) {
        const player = this.levelPlayerColors[this.currentPlayer];
        const lineObj = this.lineObjects[type][r][c];

        // Save move for undo
        this.lastMove = { type, r, c, player: this.currentPlayer };

        // Mark line as played
        if (type === 'h') this.hLines[r][c] = player.id;
        else this.vLines[r][c] = player.id;

        // Visual update
        lineObj.setFillStyle(player.color);
        lineObj.setAlpha(1);
        
        // Animation
        this.tweens.add({
            targets: lineObj,
            scaleX: type === 'h' ? 1.1 : 1.2,
            scaleY: type === 'h' ? 1.2 : 1.1,
            duration: 150,
            yoyo: true
        });

        // Check for completed boxes
        const boxesCompleted = this.checkBoxes(type, r, c);
        
        if (boxesCompleted.length > 0) {
            this.handleBoxCompletion(boxesCompleted, player);
            
            // Combo bonus
            if (boxesCompleted.length > 1) {
                this.scores[this.currentPlayer] += Config.comboBonus;
                this.updateScores();
                this.showComboEffect(boxesCompleted.length);
            }
            
            // Player gets another turn
            this.resetTimer();
            if (this.isGameOver()) {
                this.handleGameOver();
            } else {
                this.updateTurnIndicator();
            }
        } else {
            // Switch turn
            this.currentPlayer = (this.currentPlayer + 1) % 2;
            this.resetTimer();
            this.updateTurnIndicator();
        }
    }

    showComboEffect(count) {
        const { width, height } = this.scale;
        const comboText = this.add.text(width / 2, height / 2, `كومبو! +${Config.comboBonus}`, {
            fontSize: '40px',
            fontWeight: 'bold',
            fontFamily: Config.fontFamily,
            color: '#ffff00',
            stroke: '#000000',
            strokeThickness: 6
        }).setOrigin(0.5).setAlpha(0);

        this.tweens.add({
            targets: comboText,
            alpha: 1,
            scale: 1.3,
            duration: 300,
            yoyo: true,
            onComplete: () => comboText.destroy()
        });
    }

    checkBoxes(type, r, c) {
        const completed = [];
        const { rows, cols } = Config.grid;

        if (type === 'h') {
            // Check box above
            if (r > 0) {
                if (this.isBoxComplete(r - 1, c)) completed.push({ r: r - 1, c });
            }
            // Check box below
            if (r < rows - 1) {
                if (this.isBoxComplete(r, c)) completed.push({ r, c });
            }
        } else {
            // Check box left
            if (c > 0) {
                if (this.isBoxComplete(r, c - 1)) completed.push({ r, c: c - 1 });
            }
            // Check box right
            if (c < cols - 1) {
                if (this.isBoxComplete(r, c)) completed.push({ r, c });
            }
        }
        return completed;
    }

    isBoxComplete(r, c) {
        // Obstacles can't be completed
        if (this.boxes[r][c] === -1) return false;
        
        return this.hLines[r][c] !== 0 &&
               this.hLines[r + 1][c] !== 0 &&
               this.vLines[r][c] !== 0 &&
               this.vLines[r][c + 1] !== 0;
    }

    handleBoxCompletion(completedBoxes, player) {
        completedBoxes.forEach(box => {
            this.boxes[box.r][box.c] = player.id;
            this.scores[this.currentPlayer]++;
            
            const boxObj = this.boxObjects[box.r][box.c];
            boxObj.setAlpha(0);
            boxObj.setFillStyle(player.boxColor);
            
            this.tweens.add({
                targets: boxObj,
                alpha: 0.5,
                duration: 400,
                ease: 'Cubic.easeOut'
            });

            // Add player initial
            const initial = this.add.text(boxObj.x, boxObj.y, player.initial, {
                fontSize: '28px',
                fontWeight: 'bold',
                fontFamily: 'Arial',
                color: '#ffffff'
            }).setOrigin(0.5).setAlpha(0);

            this.gridContainer.add(initial);

            this.tweens.add({
                targets: initial,
                alpha: 0.9,
                scale: 1.2,
                duration: 300,
                ease: 'Back.easeOut'
            });
        });

        this.updateScores();
    }

    updateScores() {
        this.playerScores.forEach((text, i) => {
            text.setText(this.scores[i].toString());
        });
    }

    scheduleAIMove() {
        if (this.isAIThinking) return;
        this.isAIThinking = true;
        
        // Show AI thinking indicator
        if (this.statusText) {
            this.statusText.setText('الحاسوب يفكر...');
        }
        
        const aiSettings = Config.ai[this.aiDifficulty];
        
        this.time.delayedCall(aiSettings.thinkTime, () => {
            this.makeAIMove();
            this.isAIThinking = false;
        });
    }

    makeAIMove() {
        // Use randomness based on difficulty
        const aiSettings = Config.ai[this.aiDifficulty];
        const useRandom = Math.random() < aiSettings.randomness;
        
        let bestMove = null;
        
        if (useRandom) {
            // Random valid move
            bestMove = this.getRandomValidMove();
        } else {
            // Strategic move
            bestMove = this.getBestAIMove();
        }
        
        if (bestMove) {
            this.onLineDrawn(bestMove.type, bestMove.r, bestMove.c);
        }
    }

    getRandomValidMove() {
        const levelData = Config.levels[this.currentLevel - 1];
        const { rows, cols } = { rows: levelData.rows, cols: levelData.cols };
        const validMoves = [];
        
        // Find all valid moves
        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols - 1; c++) {
                if (this.hLines[r][c] === 0) {
                    validMoves.push({ type: 'h', r, c });
                }
            }
        }
        
        for (let r = 0; r < rows - 1; r++) {
            for (let c = 0; c < cols; c++) {
                if (this.vLines[r][c] === 0) {
                    validMoves.push({ type: 'v', r, c });
                }
            }
        }
        
        return validMoves.length > 0 ? validMoves[Math.floor(Math.random() * validMoves.length)] : null;
    }

    getBestAIMove() {
        const levelData = Config.levels[this.currentLevel - 1];
        const { rows, cols } = { rows: levelData.rows, cols: levelData.cols };
        
        // Priority 1: Complete a box if possible
        let completingMoves = [];
        let blockingMoves = [];
        let safeMoves = [];
        
        // Check horizontal lines
        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols - 1; c++) {
                if (this.hLines[r][c] === 0) {
                    const boxesCompleted = this.simulateMove('h', r, c);
                    if (boxesCompleted > 0) {
                        completingMoves.push({ type: 'h', r, c, boxes: boxesCompleted });
                    } else if (this.wouldGiveOpponentBox('h', r, c)) {
                        // Avoid giving opponent a box
                    } else {
                        safeMoves.push({ type: 'h', r, c });
                    }
                }
            }
        }
        
        // Check vertical lines
        for (let r = 0; r < rows - 1; r++) {
            for (let c = 0; c < cols; c++) {
                if (this.vLines[r][c] === 0) {
                    const boxesCompleted = this.simulateMove('v', r, c);
                    if (boxesCompleted > 0) {
                        completingMoves.push({ type: 'v', r, c, boxes: boxesCompleted });
                    } else if (this.wouldGiveOpponentBox('v', r, c)) {
                        // Avoid
                    } else {
                        safeMoves.push({ type: 'v', r, c });
                    }
                }
            }
        }
        
        // Best strategy: complete boxes, otherwise play safe moves
        if (completingMoves.length > 0) {
            completingMoves.sort((a, b) => b.boxes - a.boxes);
            return completingMoves[0];
        }
        
        if (safeMoves.length > 0) {
            return safeMoves[Math.floor(Math.random() * safeMoves.length)];
        }
        
        // Fallback: any valid move
        return this.getRandomValidMove();
    }

    simulateMove(type, r, c) {
        // Temporarily apply the move
        if (type === 'h') this.hLines[r][c] = 999;
        else this.vLines[r][c] = 999;
        
        const boxes = this.checkBoxes(type, r, c).length;
        
        // Undo simulation
        if (type === 'h') this.hLines[r][c] = 0;
        else this.vLines[r][c] = 0;
        
        return boxes;
    }

    wouldGiveOpponentBox(type, r, c) {
        // Check if this move creates a box with 3 sides for opponent
        const levelData = Config.levels[this.currentLevel - 1];
        const { rows, cols } = { rows: levelData.rows, cols: levelData.cols };
        
        if (type === 'h') {
            // Check boxes above and below
            if (r > 0) {
                const sidesAbove = this.countBoxSides(r - 1, c);
                if (sidesAbove === 2) return true; // Would make 3 sides
            }
            if (r < rows - 1) {
                const sidesBelow = this.countBoxSides(r, c);
                if (sidesBelow === 2) return true;
            }
        } else {
            // Check boxes left and right
            if (c > 0) {
                const sidesLeft = this.countBoxSides(r, c - 1);
                if (sidesLeft === 2) return true;
            }
            if (c < cols - 1) {
                const sidesRight = this.countBoxSides(r, c);
                if (sidesRight === 2) return true;
            }
        }
        
        return false;
    }

    countBoxSides(r, c) {
        if (this.boxes[r][c] === -1) return 0; // Obstacle
        
        let sides = 0;
        if (this.hLines[r][c] !== 0) sides++;
        if (this.hLines[r + 1][c] !== 0) sides++;
        if (this.vLines[r][c] !== 0) sides++;
        if (this.vLines[r][c + 1] !== 0) sides++;
        return sides;
    }

    updateTurnIndicator() {
        const player = this.levelPlayerColors[this.currentPlayer];
        this.statusText.setText(`دور: ${player.name}`);
        this.statusText.setBackgroundColor(player.colorHex + 'AA');
        
        // Pulse effect on current player label
        this.playerLabels.forEach((label, i) => {
            if (i === this.currentPlayer) {
                label.setAlpha(1).setScale(1.1);
                this.playerScores[i].setScale(1.1);
            } else {
                label.setAlpha(0.5).setScale(1);
                this.playerScores[i].setScale(1);
            }
        });

        // Update undo button visibility
        this.undoButtons.forEach((btn, i) => {
            if (i === this.currentPlayer && this.undoAvailable[i] && this.lastMove && this.lastMove.player === i) {
                btn.setAlpha(1);
            } else {
                btn.setAlpha(0.3);
            }
        });
    }

    startTurnTimer() {
        const levelData = Config.levels[this.currentLevel - 1];
        this.turnTimer = levelData.turnTime;
        this.updateTimerDisplay();

        if (this.timerEvent) this.timerEvent.remove();
        
        this.timerEvent = this.time.addEvent({
            delay: 1000,
            callback: this.onTimerTick,
            callbackScope: this,
            loop: true
        });
        
        // Trigger AI move if it's AI's turn
        if (this.gameMode === 'ai' && this.currentPlayer === 1) {
            this.scheduleAIMove();
        }
    }

    resetTimer() {
        const levelData = Config.levels[this.currentLevel - 1];
        this.turnTimer = levelData.turnTime;
        this.updateTimerDisplay();
        
        // Trigger AI move if it's AI's turn
        if (this.gameMode === 'ai' && this.currentPlayer === 1 && !this.isAIThinking) {
            this.scheduleAIMove();
        }
    }

    onTimerTick() {
        this.turnTimer--;
        this.updateTimerDisplay();

        if (this.turnTimer <= 0) {
            this.onTimeOut();
        }
    }

    updateTimerDisplay() {
        this.timerText.setText(this.turnTimer.toString());
        
        if (this.turnTimer <= 5) {
            this.timerText.setColor('#ff0000');
            this.timerText.setScale(1.2);
        } else {
            this.timerText.setColor('#ffffff');
            this.timerText.setScale(1);
        }
    }

    onTimeOut() {
        // Player loses turn
        this.currentPlayer = (this.currentPlayer + 1) % 2;
        this.resetTimer();
        this.updateTurnIndicator();
        
        // Show timeout message
        const { width, height } = this.scale;
        const msg = this.add.text(width / 2, height / 2, 'انتهى الوقت!', {
            fontSize: '36px',
            fontWeight: 'bold',
            fontFamily: Config.fontFamily,
            color: '#ff0000',
            stroke: '#000000',
            strokeThickness: 6
        }).setOrigin(0.5).setAlpha(0);

        this.tweens.add({
            targets: msg,
            alpha: 1,
            duration: 200,
            yoyo: true,
            hold: 500,
            onComplete: () => msg.destroy()
        });
    }

    usePowerUp(playerIndex, powerUpType) {
        // Only current player can use power-ups
        if (playerIndex !== this.currentPlayer) return;
        
        // Check if player has this power-up available
        if (this.powerUpsRemaining[playerIndex][powerUpType] <= 0) return;
        
        // AI can't use power-ups
        if (this.gameMode === 'ai' && playerIndex === 1) return;

        // Execute power-up effect
        switch(powerUpType) {
            case 'suggestMove':
                this.showSuggestedMove();
                break;
            case 'skipTurn':
                this.skipOpponentTurn();
                break;
            case 'addTime':
                this.addExtraTime();
                break;
        }

        // Decrease power-up count
        this.powerUpsRemaining[playerIndex][powerUpType]--;
        this.updatePowerUpUI(playerIndex, powerUpType);
    }

    showSuggestedMove() {
        // Clear previous suggestion
        if (this.suggestedLine) {
            this.suggestedLine.destroy();
            this.suggestedLine = null;
        }

        // Get best move using AI logic
        const bestMove = this.getBestAIMove();
        
        if (!bestMove) return;

        // Highlight the suggested line with pulsing animation
        const lineObj = this.lineObjects[bestMove.type][bestMove.r][bestMove.c];
        
        // Store original values
        const originalColor = lineObj.fillColor;
        const originalAlpha = lineObj.alpha;

        // Create pulsing effect
        this.tweens.add({
            targets: lineObj,
            alpha: 0.8,
            duration: 500,
            yoyo: true,
            repeat: 3,
            onComplete: () => {
                lineObj.setAlpha(originalAlpha);
            }
        });

        // Change color temporarily
        lineObj.setFillStyle(0xFFEB3B);
        
        this.time.delayedCall(2000, () => {
            lineObj.setFillStyle(0xcccccc);
        });

        // Show text hint
        const { width, height } = this.scale;
        const hintText = this.add.text(width / 2, height / 2, 'الخط المقترح يتوهج!', {
            fontSize: '24px',
            fontFamily: Config.fontFamily,
            fontWeight: 'bold',
            color: '#FFD700',
            stroke: '#000000',
            strokeThickness: 4
        }).setOrigin(0.5).setAlpha(0).setDepth(50);

        this.tweens.add({
            targets: hintText,
            alpha: 1,
            duration: 300,
            yoyo: true,
            hold: 1000,
            onComplete: () => hintText.destroy()
        });
    }

    skipOpponentTurn() {
        // Skip opponent's next turn
        const { width, height } = this.scale;
        
        // Show notification
        const skipText = this.add.text(width / 2, height / 2, 'تم تخطي دور الخصم!', {
            fontSize: '32px',
            fontFamily: Config.fontFamily,
            fontWeight: 'bold',
            color: '#FF9800',
            stroke: '#000000',
            strokeThickness: 6
        }).setOrigin(0.5).setAlpha(0).setDepth(50);

        this.tweens.add({
            targets: skipText,
            alpha: 1,
            scale: 1.2,
            duration: 300,
            yoyo: true,
            hold: 800,
            onComplete: () => skipText.destroy()
        });

        // Force turn change twice (skip opponent)
        this.time.delayedCall(1200, () => {
            this.currentPlayer = (this.currentPlayer + 1) % 2; // To opponent
            this.currentPlayer = (this.currentPlayer + 1) % 2; // Back to current player
            this.resetTimer();
            this.updateTurnIndicator();
        });
    }

    addExtraTime() {
        // Add 5 seconds to current turn
        this.turnTimer += 5;
        this.updateTimerDisplay();

        // Show notification
        const { width, height } = this.scale;
        const timeText = this.add.text(width / 2, height * 0.12, '+5 ثواني!', {
            fontSize: '28px',
            fontFamily: Config.fontFamily,
            fontWeight: 'bold',
            color: '#2196F3',
            stroke: '#000000',
            strokeThickness: 4
        }).setOrigin(0.5).setAlpha(0);

        this.tweens.add({
            targets: timeText,
            alpha: 1,
            y: height * 0.1,
            duration: 300,
            ease: 'Back.easeOut',
            yoyo: true,
            hold: 500,
            onComplete: () => timeText.destroy()
        });

        // Pulse timer
        this.tweens.add({
            targets: this.timerText,
            scale: 1.3,
            duration: 200,
            yoyo: true
        });
    }

    updatePowerUpUI(playerIndex, powerUpType) {
        // Find and update the specific power-up button
        const powerUpData = this.powerUpButtons[playerIndex].find(p => p.type === powerUpType);
        
        if (powerUpData) {
            const remaining = this.powerUpsRemaining[playerIndex][powerUpType];
            powerUpData.count.setText(remaining.toString());
            
            if (remaining <= 0) {
                powerUpData.button.setAlpha(0.3);
                powerUpData.count.setAlpha(0.3);
                powerUpData.button.disableInteractive();
            }
        }
    }

    handleUndo(playerIndex) {
        if (playerIndex !== this.currentPlayer) return;
        if (!this.undoAvailable[playerIndex]) return;
        if (!this.lastMove || this.lastMove.player !== playerIndex) return;

        const { type, r, c } = this.lastMove;

        // Remove line
        if (type === 'h') {
            this.hLines[r][c] = 0;
            this.lineObjects.h[r][c].setFillStyle(0xcccccc).setAlpha(0.15);
        } else {
            this.vLines[r][c] = 0;
            this.lineObjects.v[r][c].setFillStyle(0xcccccc).setAlpha(0.15);
        }

        // Mark undo as used
        this.undoAvailable[playerIndex] = false;
        this.undoButtons[playerIndex].setAlpha(0.3);
        this.lastMove = null;

        // Note: We don't revert boxes or scores for simplicity
        // This is a basic undo that only removes the last line
    }

    isGameOver() {
        // Game is over when all non-obstacle boxes are filled
        return this.boxes.every(row => row.every(box => box !== 0));
    }

    handleGameOver() {
        if (this.timerEvent) this.timerEvent.remove();

        let message = '';
        let winnerColor = '#ffffff';
        let winnerIndex = -1;
        
        if (this.scores[0] > this.scores[1]) {
            message = `${Config.players[0].name} يفوز!`;
            winnerColor = Config.players[0].colorHex;
            winnerIndex = 0;
            this.totalWins[0]++;
        } else if (this.scores[1] > this.scores[0]) {
            message = `${Config.players[1].name} يفوز!`;
            winnerColor = Config.players[1].colorHex;
            winnerIndex = 1;
            this.totalWins[1]++;
        } else {
            message = 'تعادل!';
        }

        const { width, height } = this.scale;
        const hasNextLevel = this.currentLevel < Config.levels.length;

        // Overlay
        const overlay = this.add.rectangle(width / 2, height / 2, width, height, 0x000000, 0.7)
            .setOrigin(0.5)
            .setDepth(100);

        // Level Complete text
        const levelCompleteText = this.add.text(width / 2, height * 0.3, 
            `المستوى ${this.currentLevel} مكتمل!`, {
            fontSize: '40px',
            fontWeight: 'bold',
            fontFamily: 'Arial',
            color: '#FFD700',
            stroke: '#000000',
            strokeThickness: 6
        }).setOrigin(0.5).setDepth(101);

        // Winner text
        const winnerText = this.add.text(width / 2, height * 0.4, message, {
            fontSize: '32px',
            fontWeight: 'bold',
            fontFamily: 'Arial',
            color: winnerColor,
            stroke: '#000000',
            strokeThickness: 5
        }).setOrigin(0.5).setDepth(101);

        // Score display
        const scoreText = this.add.text(width / 2, height * 0.48, 
            `النقاط: ${this.scores[0]} - ${this.scores[1]}`, {
            fontSize: '28px',
            fontWeight: 'bold',
            fontFamily: 'Arial',
            color: '#ffffff'
        }).setOrigin(0.5).setDepth(101);

        // Total wins
        const winsText = this.add.text(width / 2, height * 0.55, 
            `الفوز الكلي: ${this.totalWins[0]} - ${this.totalWins[1]}`, {
            fontSize: '24px',
            fontFamily: 'Arial',
            color: '#aaaaaa'
        }).setOrigin(0.5).setDepth(101);

        let yPos = height * 0.65;

        // Next level button (if available)
        if (hasNextLevel) {
            const nextLevelBtn = this.add.text(width / 2, yPos, 'المستوى التالي ⟩', {
                fontSize: '26px',
                fontFamily: 'Arial',
                color: '#ffffff',
                backgroundColor: '#2196F3',
                padding: { x: 25, y: 12 }
            }).setOrigin(0.5).setDepth(101).setInteractive();

            nextLevelBtn.on('pointerdown', () => {
                this.scene.start('PlayerSetupScene', { 
                    level: this.currentLevel + 1
                });
            });
            nextLevelBtn.on('pointerover', () => nextLevelBtn.setScale(1.1));
            nextLevelBtn.on('pointerout', () => nextLevelBtn.setScale(1));

            yPos += 0.08 * height;
        }

        // Replay level button
        const replayBtn = this.add.text(width / 2, yPos, 'إعادة المستوى', {
            fontSize: '24px',
            fontFamily: 'Arial',
            color: '#ffffff',
            backgroundColor: '#4CAF50',
            padding: { x: 25, y: 12 }
        }).setOrigin(0.5).setDepth(101).setInteractive();

        replayBtn.on('pointerdown', () => {
            this.scene.start('PlayerSetupScene', { 
                level: this.currentLevel
            });
        });
        replayBtn.on('pointerover', () => replayBtn.setScale(1.1));
        replayBtn.on('pointerout', () => replayBtn.setScale(1));

        yPos += 0.08 * height;

        // Back to level 1 button
        const backBtn = this.add.text(width / 2, yPos, 'العودة للمستوى 1', {
            fontSize: '22px',
            fontFamily: 'Arial',
            color: '#ffffff',
            backgroundColor: '#666666',
            padding: { x: 20, y: 10 }
        }).setOrigin(0.5).setDepth(101).setInteractive();

        backBtn.on('pointerdown', () => {
            this.scene.restart({ level: 1, totalWins: [0, 0] });
        });
        backBtn.on('pointerover', () => backBtn.setScale(1.1));
        backBtn.on('pointerout', () => backBtn.setScale(1));
    }

    handleResize(gameSize) {
        const { width, height } = gameSize;
        
        // Reposition BG
        const bg = this.children.getByName('bg');
        if (bg) {
            bg.setPosition(width / 2, height / 2);
            bg.setDisplaySize(width, height);
        }

        const levelData = Config.levels[this.currentLevel - 1];
        const rows = levelData.rows;
        const cols = levelData.cols;
        
        // Dynamic spacing based on screen size and grid size
        const maxWidth = width * 0.85;
        const maxHeight = height * 0.55;
        const spacingByWidth = maxWidth / (cols - 1);
        const spacingByHeight = maxHeight / (rows - 1);
        const spacing = Math.min(spacingByWidth, spacingByHeight, Config.grid.spacing);
        
        const gridWidth = (cols - 1) * spacing;
        const gridHeight = (rows - 1) * spacing;

        // Center grid with more space for mobile
        const topMargin = height * 0.22;
        const bottomMargin = height * 0.1;
        const availableHeight = height - topMargin - bottomMargin;
        
        this.gridContainer.setPosition(
            width / 2 - gridWidth / 2,
            topMargin + (availableHeight - gridHeight) / 2
        );

        // Position dots and lines
        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                this.dots[r][c].setPosition(c * spacing, r * spacing);
                
                if (c < cols - 1) {
                    this.lineObjects.h[r][c].setPosition(c * spacing, r * spacing);
                }
                if (r < rows - 1) {
                    this.lineObjects.v[r][c].setPosition(c * spacing, r * spacing);
                }
                if (r < rows - 1 && c < cols - 1) {
                    const boxObj = this.boxObjects[r][c];
                    boxObj.setPosition(c * spacing + spacing / 2, r * spacing + spacing / 2);
                    
                    // Position obstacle marks if they exist
                    const marks = boxObj.getData('obstacleMarks');
                    if (marks) {
                        marks.forEach(mark => {
                            mark.setPosition(c * spacing + spacing / 2, r * spacing + spacing / 2);
                        });
                    }
                }
            }
        }

        // Reposition UI
        const margin = width * 0.05;
        this.playerLabels.forEach((label, i) => {
            const x = i === 0 ? margin + 80 : width - margin - 80;
            const y = height * 0.08;
            label.setPosition(x, y);
            this.playerScores[i].setPosition(x, y + 35);
            this.undoButtons[i].setPosition(x, y + 75);
            
            // Reposition power-up buttons
            const powerUpY = y + 105;
            const powerUpSpacing = 38;
            if (this.powerUpButtons[i]) {
                this.powerUpButtons[i].forEach((powerUp, pIdx) => {
                    const xOffset = (pIdx - 1) * powerUpSpacing;
                    powerUp.button.setPosition(x + xOffset, powerUpY);
                    powerUp.count.setPosition(x + xOffset + 12, powerUpY - 12);
                });
            }
        });

        if (this.timerText) this.timerText.setPosition(width / 2, height * 0.06);
        if (this.statusText) this.statusText.setPosition(width / 2, height * 0.92);
        if (this.levelText) this.levelText.setPosition(width / 2, height * 0.14);
        if (this.menuButton) this.menuButton.setPosition(margin, height * 0.92);
    }
}
