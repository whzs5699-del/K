import Phaser from 'phaser';
import { Config } from '../Config.js';

export class MenuScene extends Phaser.Scene {
    constructor() {
        super('MenuScene');
    }

    preload() {
        this.load.image('bg', 'assets/game-background-vibrant.webp');
    }

    create() {
        const { width, height } = this.scale;

        // Background
        this.add.image(width / 2, height / 2, 'bg')
            .setOrigin(0.5)
            .setAlpha(0.5)
            .setDisplaySize(width, height);

        // Title
        this.add.text(width / 2, height * 0.15, 'لعبة النقاط والمستطيلات', {
            fontSize: '36px',
            fontWeight: 'bold',
            fontFamily: 'Arial',
            color: '#ffffff',
            stroke: '#000000',
            strokeThickness: 6,
            align: 'center'
        }).setOrigin(0.5);

        // Subtitle
        this.add.text(width / 2, height * 0.23, 'اختر المستوى', {
            fontSize: '24px',
            fontFamily: 'Arial',
            color: '#aaaaaa',
            align: 'center'
        }).setOrigin(0.5);

        // Level selection grid
        const levelsPerRow = 5;
        const buttonSize = Math.min(width * 0.15, 70);
        const spacing = buttonSize + 20;
        const startX = width / 2 - (levelsPerRow * spacing) / 2 + spacing / 2;
        const startY = height * 0.35;

        Config.levels.forEach((levelData, index) => {
            const level = index + 1;
            const row = Math.floor(index / levelsPerRow);
            const col = index % levelsPerRow;
            
            const x = startX + col * spacing;
            const y = startY + row * spacing;

            // Level button background
            const btnBg = this.add.circle(x, y, buttonSize / 2, 0x2196F3, 0.8);
            
            // Level number
            const levelText = this.add.text(x, y - 8, level.toString(), {
                fontSize: '28px',
                fontWeight: 'bold',
                fontFamily: 'Arial',
                color: '#ffffff'
            }).setOrigin(0.5);

            // Grid size info
            const infoText = this.add.text(x, y + 12, `${levelData.cols-1}×${levelData.rows-1}`, {
                fontSize: '12px',
                fontFamily: 'Arial',
                color: '#ffffff'
            }).setOrigin(0.5);

            // Obstacle indicator
            if (levelData.obstacles && levelData.obstacles.length > 0) {
                const obstacleIcon = this.add.text(x + buttonSize * 0.35, y - buttonSize * 0.35, '⚠', {
                    fontSize: '16px',
                    color: '#FFD700'
                }).setOrigin(0.5);
            }

            // Make interactive
            btnBg.setInteractive({ useHandCursor: true });
            
            btnBg.on('pointerover', () => {
                btnBg.setScale(1.1);
                levelText.setScale(1.1);
                infoText.setScale(1.1);
            });
            
            btnBg.on('pointerout', () => {
                btnBg.setScale(1);
                levelText.setScale(1);
                infoText.setScale(1);
            });
            
            btnBg.on('pointerdown', () => {
                this.scene.start('PlayerSetupScene', { level });
            });
        });

        // Instructions
        const instructionY = height * 0.78;
        this.add.text(width / 2, instructionY, 'كيف تلعب:', {
            fontSize: '20px',
            fontWeight: 'bold',
            fontFamily: 'Arial',
            color: '#ffffff'
        }).setOrigin(0.5);

        const instructions = [
            'اسحب من نقطة إلى نقطة لرسم خط',
            'أكمل 4 خطوط لتكوين مستطيل',
            'المستطيلات = نقاط، أكثر نقاط = فوز',
            'لديك 15 ثانية لكل دور'
        ];

        instructions.forEach((text, i) => {
            this.add.text(width / 2, instructionY + 30 + (i * 22), text, {
                fontSize: '14px',
                fontFamily: 'Arial',
                color: '#cccccc',
                align: 'center'
            }).setOrigin(0.5);
        });

        // Handle resize
        this.scale.on('resize', this.handleResize, this);
    }

    handleResize(gameSize) {
        // Menu layout is static for simplicity
        // In production, you'd want to reposition elements
    }
}
